# Buscador de Clima usando HTML, CSS, JavaScript

Este repositorio es el producto final de este video de YouTube

📹 https://youtu.be/ScFv80QmEps

Utilizamos el API de [Open Weather Map](https://openweathermap.org/api/one-call-api)

Si quieres obtener tu propio token de API puedes hacerlo creando una cuenta allí, sino utiliza el que viene con el proyecto.

### Links

* [Instagram](https://instagram.com/codealo)
* [YouTube](https://www.youtube.com/channel/UCLdBO2AVbCohANbEtEHn1CA)
* [Página Web](https://codealo.dev)